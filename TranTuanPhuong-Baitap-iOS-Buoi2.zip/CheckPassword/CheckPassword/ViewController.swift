//
//  ViewController.swift
//  CheckPassword
//
//  Created by TranTPhuong on 11/29/16.
//  Copyright © 2016 TranTPhuong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tfInput: UITextField!
    
    @IBOutlet weak var lblDisplay: UILabel!
    let password:String = "abc123"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func txtFieldInputed(_ sender: Any) {
        let inputPassword = tfInput.text!
        if inputPassword == password {
            lblDisplay.text = "Correct password"
        } else {
            lblDisplay.text = "Wrong password"
        }
    }

}

